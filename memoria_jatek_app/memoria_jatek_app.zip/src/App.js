import './App.css';
import MemoryGame from "./MemoryGame";

function App() {
  return (
    <div className="App">
      <MemoryGame />
    </div>
  );
}

export default App;
