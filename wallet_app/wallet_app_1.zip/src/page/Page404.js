import * as React from "react";

function Page404() {
  return <div>Page404</div>;
}

export default Page404;
